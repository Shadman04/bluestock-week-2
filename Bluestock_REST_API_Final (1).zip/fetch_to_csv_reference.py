"""Call a public REST API, inspect the JSON, and save it as a CSV.

Uses JSONPlaceholder, a free fake-data API that needs no authentication.
Install dependencies with:  pip install requests pandas
"""
import requests
import pandas as pd

URL = "https://jsonplaceholder.typicode.com/users"


def fetch_json(url: str):
    response = requests.get(url, timeout=10)
    response.raise_for_status()  # stop early on HTTP errors
    return response.json()


def json_to_csv(records, path: str = "users.csv") -> None:
    # json_normalize flattens nested objects, e.g. address.city -> "address.city"
    df = pd.json_normalize(records)
    df.to_csv(path, index=False)
    print(f"Saved {len(df)} rows and {len(df.columns)} columns to {path}")


if __name__ == "__main__":
    data = fetch_json(URL)
    print(f"Received {len(data)} records")
    json_to_csv(data)
